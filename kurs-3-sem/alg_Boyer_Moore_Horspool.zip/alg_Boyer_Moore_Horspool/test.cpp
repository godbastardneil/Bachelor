#include "test.h"
#include "ui_test.h"

test::test(QWidget *parent) : QWidget(parent), ui(new Ui::test)
{
    ui->setupUi(this);
}

test::~test() { delete ui; }

void test::read_test(const QString u_name)
{
    name = u_name;
    if (reader::Instance().read_text(fname)) {
        testing = test_comp::Instance().create_test(reader::Instance().get_text());
        n = testing.size();
        w.resize(n);
        i = 0;
        ui->qwest->setText(testing[i].question);
        ui->stud_c->setEnabled(false);
        ui->l_back->setEnabled(true);
        ui->l_forward->setEnabled(true);
        ui->end_test->setEnabled(true);
    }
    reader::Instance().set_text("");
}

void test::show_test()
{
    ui->qwest->setText(QString::number(i) + ". " + testing[i].question);
    int m = testing[i].q_answer.size();
    if (m>1) {
        for (int j=0; j<m; ++j) {
            ui->qwest->append(QString::number(j+1) + ". " + testing[i].q_answer[j].ans);
        }
    }

}

void test::on_l_back_clicked()
{
    ui->stud_c->setEnabled(true);
    --i;
    if (i<1) { i = n-1; }
    show_test();
}

void test::on_l_forward_clicked()
{
    ui->stud_c->setEnabled(true);
    ++i;
    if (i==n) { i=1; }
    show_test();
}


void test::on_stud_c_textChanged(const QString &arg1)
{
    w[i] = test_comp::Instance().check_ans(testing[i].q_answer, arg1);
}

void test::on_end_test_clicked()
{
    ui->stud_c->setEnabled(false);
    ui->l_back->setEnabled(false);
    ui->l_forward->setEnabled(false);
    ui->end_test->setEnabled(false);
    int win = 0;
    for (int j=1; j<n; ++j) { win += w[j]; }
    w.clear();
    ui->qwest->setText(test_comp::Instance().input_stat(name, win));
}
