#include "dialog.h"
#include "ui_dialog.h"

dialog::dialog(QWidget *parent) : QDialog(parent), ui(new Ui::dialog)
{
    ui->setupUi(this);
    c = false; set_name(""); set_password("");
}

dialog::~dialog() { delete ui; }

void dialog::on_name_textChanged(const QString &arg1) { set_name(arg1); }

void dialog::on_password_textChanged(const QString &arg1) { set_password(arg1); }

void dialog::on_buttonBox_accepted() { c = false; close(); }

void dialog::on_buttonBox_rejected() { c = true; close(); }
