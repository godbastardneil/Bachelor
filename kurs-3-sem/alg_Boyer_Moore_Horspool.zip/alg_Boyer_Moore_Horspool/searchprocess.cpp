#include "searchprocess.h"

int searchprocess::is(const QChar &c, const int &i)
{
    int n = pattern.size()-2;
    for (int j=n; j>i; --j) {
        if (c == pattern[j]) { return n-j+1; }
    }
    return n-i+1;
}
void searchprocess::table()
{
    d[dm-1] = d[dm-2] = dm-1;
    for (int i=dm-3; i>=0; --i) {
        d[i] = is(pattern[i], i);
    }
    d[dm-2] = is(pattern[dm-2], -1);
}

// b - каким цветом выделить <---> 1 - сравнение соответствующих букв
//                                 0 - поиск буквы в подстроке
// p - страница визуализации и количество \n
// j - символ шаблома, который участвует в алгоритме
// m - размер шаблона
// i - количество отступов и номер первого элемента сравниваемой части строки
void searchprocess::present(bool b, int p, int j, int m, int i)
{
    proz[p].push_back("<pre>" + str + QString(p+1, '\n') + QString(i, ' '));
    int n = proz[p].size()-1;
    proz[p][n].append(pattern.data(), j);
    if (b) {
        proz[p][n] += "<font color=\"green\">";
    } else {
        proz[p][n] += "<font color=\"red\">";
    }
    proz[p][n] += pattern[j] + "</font>";

    for (int k=j+1; k<m; ++k) { proz[p][n] += pattern[k]; }
    proz[p][n] += "</pre>";
}

bool searchprocess::BMH()
{
    int n = str.size();
    int m = pattern.size();

    QVector<QString> qvs;
    if (n < m) {
        proz.push_back(qvs);
        proz[0].push_back("<pre>pattern длинее str</pre>");
        return 0;
    }
    dm = m+1;
    d = new int[dm];
    table();

    for (int i=0, p=0, j=0, l=0; (i<n); i += d[j], ++p) {
        proz.push_back(qvs);
        proz[p].push_back("<pre>" + str + QString(p+1, '\n') + QString(i, ' ') + pattern + "</pre>");
        for (j=m-1; (j>=0) && (str[i+j] == pattern[j]); --j) {
            present(1, p, j, m, i);
        }

        if (j == -1) {
            return 1;
        } else {
            for (l = m-1; (l >= 0) && (str[i+m-1] != pattern[l]); --l) {
                present(0, p, l, m, i);
            }

            if(l != -1) {
                j = l;
            } else { j = m; }
        }
    }
    return 0;
}
