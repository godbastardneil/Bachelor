#ifndef READER_H
#define READER_H

#include <fstream>
#include <QString>

class reader
{

public:
    static reader& Instance() {
        static reader Instance;
        return Instance;
    }
    void set_text (const QString &qs) {
        text.clear();
        text = qs;
    }
    QString get_text () { return text; }
    int get_code () { return code; }

    bool read_text(const QString &name);

private:
    int code = 0xAABBC53; // ключ
    QString text; // текст, который будут выводить

    reader() {}
    reader(const reader &)  = delete;
    reader(const reader &&) = delete;
    reader& operator=(const reader &)  = delete;
    reader& operator=(const reader &&) = delete;
};

#endif // READER_H
