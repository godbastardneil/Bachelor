#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>

namespace Ui { class dialog; }

class dialog : public QDialog
{
    Q_OBJECT

public:
    explicit dialog(QWidget *parent = nullptr);
    ~dialog();

    void set_name(const QString &qs) {
        name = qs;
        name.remove(' ');
    }
    void set_password(const QString &qs) {
        password = qs;
    }
    QString get_name() { return name; }
    QString get_password() { return password; }
    bool isCancel() { return c; }

private slots:
    void on_name_textChanged(const QString &arg1);
    void on_password_textChanged(const QString &arg1);
    void on_buttonBox_accepted();
    void on_buttonBox_rejected();

private:
    Ui::dialog *ui;

    QString name; // введеное имя
    QString password; // введеный пароль
    bool c;

    dialog(const dialog &)  = delete;
    dialog(const dialog &&) = delete;
    dialog& operator=(const dialog &)  = delete;
    dialog& operator=(const dialog &&) = delete;
};

#endif // DIALOG_H
